Sync SS Tool
Author: blueberry

Structure:
- launch.ps1       : Starts Sync SS Tool with ExecutionPolicy Bypass
- syncsstool.ps1   : Main PowerShell WPF loader and event handlers
- src/Main.xaml    : Redesigned WPF GUI layout
- tools.json       : Tool definitions loaded into the sidebar list
