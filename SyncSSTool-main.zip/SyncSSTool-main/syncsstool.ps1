#requires -Version 5.1
Add-Type -AssemblyName PresentationFramework

$AppName = "Sync SS Tool"
$Author  = "blueberry"
$BaseDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$XamlPath = Join-Path $BaseDir "src\Main.xaml"
$ToolsJsonPath = Join-Path $BaseDir "tools.json"

if (-not (Test-Path $XamlPath)) {
    throw "Could not find Main.xaml at: $XamlPath"
}

[xml]$Xaml = Get-Content -Path $XamlPath -Raw
$Reader = New-Object System.Xml.XmlNodeReader $Xaml
$Window = [Windows.Markup.XamlReader]::Load($Reader)

# Named controls
$ToolListBox = $Window.FindName("ToolListBox")
$OutputBox   = $Window.FindName("OutputBox")
$StatusText  = $Window.FindName("StatusText")
$BtnRunTool  = $Window.FindName("BtnRunTool")
$BtnClearLog = $Window.FindName("BtnClearLog")
$BtnRefresh  = $Window.FindName("BtnRefresh")

$Window.Title = "$AppName — by $Author"

function Write-Log {
    param([string]$Message)
    $Timestamp = Get-Date -Format "HH:mm:ss"
    $OutputBox.AppendText("[$Timestamp] $Message`r`n")
    $OutputBox.ScrollToEnd()
}

function Load-Tools {
    $ToolListBox.Items.Clear()
    if (Test-Path $ToolsJsonPath) {
        try {
            $Tools = Get-Content -Path $ToolsJsonPath -Raw | ConvertFrom-Json
            foreach ($Item in $Tools) {
                [void]$ToolListBox.Items.Add($Item)
            }
            $StatusText.Text = "Loaded $($ToolListBox.Items.Count) tools — $AppName by $Author"
            Write-Log "Loaded tools from tools.json"
        }
        catch {
            Write-Log "Error reading tools.json: $($_.Exception.Message)"
        }
    }
    else {
        foreach ($Fallback in @("Process Check", "Recent Files", "Network Connections")) {
            [void]$ToolListBox.Items.Add([PSCustomObject]@{ Name = $Fallback })
        }
        $StatusText.Text = "Using default tool list — $AppName by $Author"
    }
}

$BtnRefresh.Add_Click({
    Load-Tools
})

$BtnClearLog.Add_Click({
    $OutputBox.Clear()
    $StatusText.Text = "Output cleared — $AppName by $Author"
})

$BtnRunTool.Add_Click({
    $Selected = $ToolListBox.SelectedItem
    if ($null -eq $Selected) {
        Write-Log "Select a tool from the list first."
        return
    }
    $ToolName = if ($Selected.PSObject.Properties["Name"]) { $Selected.Name } else { "$Selected" }
    $StatusText.Text = "Running '$ToolName'... — $AppName by $Author"
    Write-Log "Executing: $ToolName"
    # Hook your existing execution logic here
})

Load-Tools
Write-Log "$AppName initialized (Author: $Author)."
[void]$Window.ShowDialog()
