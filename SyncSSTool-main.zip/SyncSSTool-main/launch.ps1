# Launcher for Sync SS Tool by blueberry
$BaseDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$MainScript = Join-Path $BaseDir "syncsstool.ps1"
Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$MainScript`""
